package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Issue;

@Repository
public interface IssueRepository extends JpaRepository<Issue, Long> {
    // Additional methods for specific queries can be added here if needed
	
	List<Issue> findByStudentId(Long studentId);
}

