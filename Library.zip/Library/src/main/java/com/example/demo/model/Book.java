package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//import javax.persistence.*;

@Entity
@Table(name = "Book")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "book_reference_number", nullable = false)
    private String bookReferenceNumber;

    @Column(name = "isbn")
    private String isbn;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "author", nullable = false)
    private String author;

    @Column(name = "publication")
    private String publication;

    @Column(name = "edition")
    private String edition;

    @Column(name = "published_year")
    private int publishedYear;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "number_of_copies", nullable = false)
    private int numberOfCopies;

	public Book(Long id, String bookReferenceNumber, String isbn, String title, String author, String publication,
			String edition, int publishedYear, String category, int numberOfCopies) {
		super();
		this.id = id;
		this.bookReferenceNumber = bookReferenceNumber;
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publication = publication;
		this.edition = edition;
		this.publishedYear = publishedYear;
		this.category = category;
		this.numberOfCopies = numberOfCopies;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBookReferenceNumber() {
		return bookReferenceNumber;
	}

	public void setBookReferenceNumber(String bookReferenceNumber) {
		this.bookReferenceNumber = bookReferenceNumber;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublication() {
		return publication;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public int getPublishedYear() {
		return publishedYear;
	}

	public void setPublishedYear(int publishedYear) {
		this.publishedYear = publishedYear;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNumberOfCopies() {
		return numberOfCopies;
	}

	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", bookReferenceNumber=" + bookReferenceNumber + ", isbn=" + isbn + ", title=" + title
				+ ", author=" + author + ", publication=" + publication + ", edition=" + edition + ", publishedYear="
				+ publishedYear + ", category=" + category + ", numberOfCopies=" + numberOfCopies + "]";
	}

    
}

