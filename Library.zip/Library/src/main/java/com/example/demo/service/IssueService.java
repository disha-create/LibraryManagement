package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ReturnRequest;
import com.example.demo.model.Issue;
import com.example.demo.repository.IssueRepository;

@Service
public class IssueService {

	@Autowired
    private IssueRepository issueRepository;

    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public Issue issueBook(Issue issue) {
        try {
            return issueRepository.save(issue);
        } catch (Exception e) {
            throw new RuntimeException("Failed to issue book: " + e.getMessage());
        }
    }

    public Optional<Issue> getIssueById(Long id) {
        return issueRepository.findById(id);
    }
    
    public List<Issue> getIssuedBooksByStudentId(Long studentId) {
        return issueRepository.findByStudentId(studentId);
    }

    public void deleteIssue(Long id) {
        try {
            issueRepository.deleteById(id);
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete issue: " + e.getMessage());
        }
    }
    
    
    public void returnIssuedBook(Long issueId, ReturnRequest returnRequest) {
        // Validate issueId
        if (issueId == null || issueId <= 0) {
            throw new IllegalArgumentException("Invalid issueId: " + issueId);
        }

        // Validate returnRequest
        if (returnRequest == null || returnRequest.getReturnDate() == null) {
            throw new IllegalArgumentException("Return request or return date cannot be null");
        }

        try {
            Issue issue = issueRepository.findById(issueId)
                                          .orElseThrow(() -> new EntityNotFoundException("Issue not found with ID: " + issueId));

            // Update return date
            issue.setReturnDate(returnRequest.getReturnDate());

            issueRepository.save(issue);
        } catch (EntityNotFoundException e) {
            // Handle the exception
            throw new RuntimeException("Issue not found with ID: " + issueId);
        } catch (Exception e) {
            // Handle other exceptions, if any
            throw new RuntimeException("Failed to return issued book: " + e.getMessage());
        }
    }

    
    
    

	
}