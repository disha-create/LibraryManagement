package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ReturnRequest;
import com.example.demo.model.Issue;
import com.example.demo.service.IssueService;

@RestController
@RequestMapping("/api/issues")
public class IssueController {

	@Autowired
    private IssueService issueService;

    @GetMapping
    public List<Issue> getAllIssues() {
        return issueService.getAllIssues();
    }

    @PostMapping
    public Issue issueBook(@RequestBody Issue issue) {
        return issueService.issueBook(issue);
    }
//
//    @GetMapping("/{id}")
//    public Issue getIssueById(@PathVariable Long id) {
//        return issueService.getIssueById(id)
//                .orElseThrow(() -> new RuntimeException("Issue not found with id: " + id));
//    }
    
    @GetMapping("/{studentId}")
    public ResponseEntity<List<Issue>> getIssuedBooksByStudentId(@PathVariable Long studentId) {
        List<Issue> issuedBooks = issueService.getIssuedBooksByStudentId(studentId);
        return ResponseEntity.ok().body(issuedBooks);
    }
    
    @PutMapping("/{issueId}/return")
    public ResponseEntity<String> returnIssuedBook(@PathVariable Long issueId, @RequestBody ReturnRequest returnRequest) {
        issueService.returnIssuedBook(issueId, returnRequest);
        return ResponseEntity.ok("Book returned successfully.");
    }


    @DeleteMapping("/{id}")
    public void deleteIssue(@PathVariable Long id) {
        issueService.deleteIssue(id);
    }

}